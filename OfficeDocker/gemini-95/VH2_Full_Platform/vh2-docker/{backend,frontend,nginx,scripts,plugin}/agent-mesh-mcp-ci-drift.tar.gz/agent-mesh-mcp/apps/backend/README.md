# Backend (Option 2: Transformers runtime scaffold)

This folder adds a **real local model runtime interface** + **real inference plumbing** with optional **LoRA adapter hooks**.

## Install

From repo root:

```bash
python -m venv .venv
source .venv/bin/activate
pip install -r apps/backend/requirements.txt
```

Optional LoRA (PEFT):

```bash
pip install -r apps/backend/requirements-peft.txt
```

## Run

```bash
export MODEL_ID="gpt2"
export DEVICE="cpu"
# optional:
# export USE_PEFT=1

uvicorn apps.backend.app:app --reload --port 8000
```

## Test

```bash
curl -s http://localhost:8000/health
curl -s http://localhost:8000/model/generate -H 'content-type: application/json' \
  -d '{"prompt":"Write a short tool-call plan for listing buckets."}'
curl -s http://localhost:8000/model/embed -H 'content-type: application/json' \
  -d '{"texts":["mcp tool: list buckets","deploy sandbox service"]}'
```

## Notes

- Embeddings are computed via **mean pooling** over the last hidden state and L2 normalization.
- `load_adapter/unload_adapter` are **no-ops** unless `USE_PEFT=1` and PEFT is installed.
