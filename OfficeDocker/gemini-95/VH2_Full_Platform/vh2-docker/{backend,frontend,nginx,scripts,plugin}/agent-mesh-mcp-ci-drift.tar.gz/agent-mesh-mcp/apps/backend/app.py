from __future__ import annotations

import os
from typing import List, Optional, Dict, Any

from fastapi import FastAPI, HTTPException
from pydantic import BaseModel

from models.interface import GenerationRequest, EmbeddingRequest
from models.hf_runtime import HFRuntime

USE_PEFT = os.getenv("USE_PEFT", "0") == "1"
HFPEFTRuntime = None
if USE_PEFT:
    try:
        from models.hf_peft_runtime import HFPEFTRuntime as _HFPEFTRuntime

        HFPEFTRuntime = _HFPEFTRuntime
    except Exception:
        HFPEFTRuntime = None

MODEL_ID = os.getenv("MODEL_ID", "gpt2")
DEVICE = os.getenv("DEVICE", "cpu")

app = FastAPI(title="agent-mesh-mcp backend (Transformers Scaffold)")

_runtime = None


def get_runtime():
    global _runtime
    if _runtime is not None:
        return _runtime

    if USE_PEFT:
        if HFPEFTRuntime is None:
            raise RuntimeError(
                "USE_PEFT=1 is set but PEFT runtime import failed. "
                "Install requirements-peft.txt and ensure 'peft' is available."
            )
        _runtime = HFPEFTRuntime(model_id=MODEL_ID, device=DEVICE)
    else:
        _runtime = HFRuntime(model_id=MODEL_ID, device=DEVICE)

    return _runtime


class GenIn(BaseModel):
    prompt: str
    max_new_tokens: int = 256
    temperature: float = 0.2
    top_p: float = 0.95
    metadata: Optional[Dict[str, Any]] = None


class EmbIn(BaseModel):
    texts: List[str]


class AdapterIn(BaseModel):
    adapter_ref: str


@app.get("/health")
def health():
    r = get_runtime()
    return {"ok": True, "model_id": r.model_id, "adapter_id": r.adapter_id, "use_peft": USE_PEFT}


@app.post("/model/generate")
def model_generate(req: GenIn):
    r = get_runtime()
    try:
        out = r.generate(
            GenerationRequest(
                prompt=req.prompt,
                max_new_tokens=req.max_new_tokens,
                temperature=req.temperature,
                top_p=req.top_p,
                metadata=req.metadata,
            )
        )
        return out.__dict__
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@app.post("/model/embed")
def model_embed(req: EmbIn):
    r = get_runtime()
    try:
        out = r.embed(EmbeddingRequest(texts=req.texts))
        return out.__dict__
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@app.post("/model/adapter/load")
def adapter_load(req: AdapterIn):
    r = get_runtime()
    try:
        r.load_adapter(req.adapter_ref)
        return {"ok": True, "adapter_id": r.adapter_id}
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))


@app.post("/model/adapter/unload")
def adapter_unload():
    r = get_runtime()
    try:
        r.unload_adapter()
        return {"ok": True, "adapter_id": r.adapter_id}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
