from __future__ import annotations

from dataclasses import dataclass
from typing import Dict, Optional
import uuid
import time


@dataclass
class LoraJob:
    job_id: str
    status: str  # queued|running|done|failed
    created_at: float
    adapter_ref: Optional[str] = None
    error: Optional[str] = None


_JOBS: Dict[str, LoraJob] = {}


def start_lora_job() -> LoraJob:
    job_id = str(uuid.uuid4())
    job = LoraJob(job_id=job_id, status="queued", created_at=time.time())
    _JOBS[job_id] = job
    return job


def get_job(job_id: str) -> Optional[LoraJob]:
    return _JOBS.get(job_id)


def mark_running(job_id: str) -> None:
    _JOBS[job_id].status = "running"


def mark_done(job_id: str, adapter_ref: str) -> None:
    _JOBS[job_id].status = "done"
    _JOBS[job_id].adapter_ref = adapter_ref


def mark_failed(job_id: str, err: str) -> None:
    _JOBS[job_id].status = "failed"
    _JOBS[job_id].error = err
