from __future__ import annotations

from dataclasses import dataclass
from typing import Optional

import torch
from transformers import AutoTokenizer, AutoModelForCausalLM, AutoModel

from .interface import (
    ModelRuntime,
    GenerationRequest,
    GenerationResponse,
    EmbeddingRequest,
    EmbeddingResponse,
)
from .hf_runtime import _mean_pool

# Optional dependency: peft
from peft import PeftModel  # type: ignore


@dataclass
class HFPEFTRuntime(ModelRuntime):
    model_id: str
    device: str = "cpu"
    adapter_id: Optional[str] = None

    def __post_init__(self) -> None:
        self.tokenizer = AutoTokenizer.from_pretrained(self.model_id, use_fast=True)
        if self.tokenizer.pad_token is None:
            self.tokenizer.pad_token = self.tokenizer.eos_token

        self.base_lm = AutoModelForCausalLM.from_pretrained(self.model_id)
        self.base_lm.to(self.device)
        self.base_lm.eval()

        self.lm = self.base_lm

        self.encoder = AutoModel.from_pretrained(self.model_id)
        self.encoder.to(self.device)
        self.encoder.eval()

    @torch.inference_mode()
    def generate(self, req: GenerationRequest) -> GenerationResponse:
        inputs = self.tokenizer(req.prompt, return_tensors="pt").to(self.device)
        out = self.lm.generate(
            **inputs,
            max_new_tokens=req.max_new_tokens,
            do_sample=(req.temperature > 0),
            temperature=req.temperature,
            top_p=req.top_p,
            pad_token_id=self.tokenizer.eos_token_id,
        )
        text = self.tokenizer.decode(out[0], skip_special_tokens=True)

        prompt_tokens = int(inputs["input_ids"].shape[-1])
        total_tokens = int(out.shape[-1])
        completion_tokens = max(0, total_tokens - prompt_tokens)

        return GenerationResponse(
            text=text,
            usage={
                "prompt_tokens": prompt_tokens,
                "completion_tokens": completion_tokens,
                "total_tokens": total_tokens,
            },
            model_id=self.model_id,
            adapter_id=self.adapter_id,
        )

    @torch.inference_mode()
    def embed(self, req: EmbeddingRequest) -> EmbeddingResponse:
        batch = self.tokenizer(
            req.texts,
            return_tensors="pt",
            padding=True,
            truncation=True,
            max_length=512,
        ).to(self.device)

        outputs = self.encoder(**batch, output_hidden_states=False, return_dict=True)
        pooled = _mean_pool(outputs.last_hidden_state, batch["attention_mask"])
        pooled = torch.nn.functional.normalize(pooled, p=2, dim=-1)

        vectors = pooled.detach().cpu().tolist()
        dim = len(vectors[0]) if vectors else 0
        return EmbeddingResponse(vectors=vectors, dim=dim, model_id=self.model_id)

    def load_adapter(self, adapter_ref: str) -> None:
        self.lm = PeftModel.from_pretrained(self.base_lm, adapter_ref)
        self.lm.to(self.device)
        self.lm.eval()
        self.adapter_id = adapter_ref

    def unload_adapter(self) -> None:
        self.lm = self.base_lm
        self.adapter_id = None
