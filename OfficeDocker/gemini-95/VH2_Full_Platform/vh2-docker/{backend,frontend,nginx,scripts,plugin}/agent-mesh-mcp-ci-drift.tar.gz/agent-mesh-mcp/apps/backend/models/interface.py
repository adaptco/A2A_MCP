from __future__ import annotations

from dataclasses import dataclass
from typing import Protocol, Optional, Dict, Any, List


@dataclass(frozen=True)
class GenerationRequest:
    prompt: str
    max_new_tokens: int = 256
    temperature: float = 0.2
    top_p: float = 0.95
    metadata: Optional[Dict[str, Any]] = None


@dataclass(frozen=True)
class GenerationResponse:
    text: str
    usage: Dict[str, int]
    model_id: str
    adapter_id: Optional[str] = None


@dataclass(frozen=True)
class EmbeddingRequest:
    texts: List[str]


@dataclass(frozen=True)
class EmbeddingResponse:
    vectors: List[List[float]]
    dim: int
    model_id: str


class ModelRuntime(Protocol):
    model_id: str
    adapter_id: Optional[str]

    def generate(self, req: GenerationRequest) -> GenerationResponse: ...

    def embed(self, req: EmbeddingRequest) -> EmbeddingResponse: ...

    def load_adapter(self, adapter_ref: str) -> None: ...

    def unload_adapter(self) -> None: ...
