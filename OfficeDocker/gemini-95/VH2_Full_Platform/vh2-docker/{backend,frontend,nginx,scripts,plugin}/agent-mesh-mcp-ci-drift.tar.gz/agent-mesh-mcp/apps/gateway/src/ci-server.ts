import http from "node:http";
import { InMemoryArtifactStore } from "@agent-mesh/artifact-store";
import { StubLLMAdapter } from "@agent-mesh/adapter-stub";
import { canonicalizeWorkflowSignature, normalizeWorkflow } from "@agent-mesh/core";
import YAML from "yaml";

type DriftCheckRequest = {
  repo: string;
  ref: string;
  workflow_path: string;
  workflow_yaml: string;
  reusable_workflows?: Record<string, string>; // key: normalized uses string (after ref normalization)
  store_as_canonical?: boolean;
};

const store = new InMemoryArtifactStore();
const llm = new StubLLMAdapter();

function json(res: http.ServerResponse, code: number, body: any) {
  const data = Buffer.from(JSON.stringify(body, null, 2));
  res.writeHead(code, {
    "content-type": "application/json; charset=utf-8",
    "content-length": data.length,
  });
  res.end(data);
}

async function readBody(req: http.IncomingMessage): Promise<any> {
  const chunks: Buffer[] = [];
  for await (const c of req) chunks.push(Buffer.isBuffer(c) ? c : Buffer.from(String(c)));
  const raw = Buffer.concat(chunks).toString("utf8");
  if (!raw) return null;
  try {
    return JSON.parse(raw);
  } catch {
    return raw;
  }
}

function parseWorkflow(yamlText: string): any {
  return YAML.parse(yamlText);
}

function resolver(map?: Record<string, string>) {
  if (!map) return () => null;
  return (uses: string) => {
    const y = map[uses];
    if (!y) return null;
    return parseWorkflow(y);
  };
}

function suggestMinimalPatch(input: DriftCheckRequest, closestCanonical?: any): string | null {
  // Heuristic: if wrapper uses reusable workflow, suggest updating its ref to match canonical.
  const wf = parseWorkflow(input.workflow_yaml);
  const jobs = wf?.jobs ?? {};
  let changed = false;

  if (closestCanonical?.signature?.jobs) {
    const canonReusable = closestCanonical.signature.jobs.find((j: any) => j.type === "reusable")?.uses ?? null;
    if (canonReusable) {
      for (const jobId of Object.keys(jobs)) {
        if (typeof jobs[jobId]?.uses === "string") {
          jobs[jobId].uses = canonReusable;
          changed = true;
        }
      }
    }
  }

  if (!changed) return null;

  wf.jobs = jobs;
  const newYaml = YAML.stringify(wf);
  return [
    `--- a/${input.workflow_path}`,
    `+++ b/${input.workflow_path}`,
    `@@`,
    `# Suggested replacement content (manual apply):`,
    ...newYaml.split("\n").map((l) => `+${l}`),
    ``,
  ].join("\n");
}

const server = http.createServer(async (req, res) => {
  try {
    if (req.method === "GET" && req.url === "/health") {
      return json(res, 200, { ok: true, snapshot: store.snapshot() });
    }

    if (req.method === "POST" && req.url === "/ci/drift-check") {
      const body = (await readBody(req)) as DriftCheckRequest;
      if (!body?.repo || !body?.workflow_yaml || !body?.workflow_path || !body?.ref) {
        return json(res, 400, { ok: false, error: "missing required fields: repo, ref, workflow_path, workflow_yaml" });
      }

      const workflow = parseWorkflow(body.workflow_yaml);
      const sig = normalizeWorkflow(workflow, { resolveReusable: resolver(body.reusable_workflows) });
      const canon = canonicalizeWorkflowSignature(sig);

      const embedding = await llm.embeddings(canon.canonicalString);

      // Optionally register as canonical
      let stored = null;
      if (body.store_as_canonical && (store as any).putWorkflowEmbedding) {
        stored = await (store as any).putWorkflowEmbedding({
          repo: body.repo,
          ref: body.ref,
          workflow_path: body.workflow_path,
          normalized_hash: canon.normalizedHash,
          canonical_string: canon.canonicalString,
          signature: canon.signature,
          embedding,
          tags: ["workflow", "canonical"],
        });
      }

      const drift = (store as any).findWorkflowDrift
        ? await (store as any).findWorkflowDrift({ normalized_hash: canon.normalizedHash, embedding, repo: body.repo })
        : { drift: true, reason: "hash_mismatch" };

      const closest = drift.drift ? drift.closestByEmbedding?.artifact ?? null : null;
      const patch = drift.drift ? suggestMinimalPatch(body, closest?.data ? { signature: (closest.data as any).signature } : null) : null;

      await store.fossil({
        event: "ci_drift_fossil",
        agentId: "gateway",
        taskTreeId: undefined,
        payload: {
          repo: body.repo,
          ref: body.ref,
          workflow_path: body.workflow_path,
          normalized_hash: canon.normalizedHash,
          drift,
          patchSuggested: Boolean(patch),
        },
      });

      return json(res, 200, {
        ok: true,
        storedCanonical: stored ? { artifactId: stored.id } : null,
        normalized: { normalizedHash: canon.normalizedHash, canonicalString: canon.canonicalString, signature: canon.signature },
        drift,
        suggestedPatch: patch,
        chain: store.verifyChain(),
      });
    }

    return json(res, 404, { ok: false, error: "not found" });
  } catch (e: any) {
    return json(res, 500, { ok: false, error: String(e?.message ?? e) });
  }
});

const port = Number(process.env.PORT ?? 8787);
server.listen(port, () => {
  console.log(`ci-server listening on http://localhost:${port}`);
});
