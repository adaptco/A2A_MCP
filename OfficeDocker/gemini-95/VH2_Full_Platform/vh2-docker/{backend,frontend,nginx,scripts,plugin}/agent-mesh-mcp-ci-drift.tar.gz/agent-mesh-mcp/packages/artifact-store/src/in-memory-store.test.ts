import { describe, expect, test } from "vitest";
import { InMemoryArtifactStore } from "./in-memory-store.js";

describe("InMemoryArtifactStore workflow embeddings", () => {
  test("putWorkflowEmbedding writes an append-only fossil and keeps chain valid", async () => {
    const store = new InMemoryArtifactStore();

    const art = await store.putWorkflowEmbedding({
      repo: "org/repo",
      ref: "main",
      workflow_path: ".github/workflows/ci.yml",
      normalized_hash: "abc123",
      canonical_string: "canon",
      signature: { schemaVersion: "workflow_signature_v1", triggers: [], jobs: [] },
      embedding: [1, 0, 0],
    });

    expect(art.type).toBe("workflow_embedding");
    const fossils = await store.fossils();
    expect(fossils.length).toBeGreaterThan(0);
    expect(store.verifyChain().valid).toBe(true);
  });

  test("findWorkflowDrift prefers normalized-hash equality, else embedding similarity", async () => {
    const store = new InMemoryArtifactStore();

    await store.putWorkflowEmbedding({
      repo: "org/repo",
      ref: "main",
      workflow_path: ".github/workflows/ci.yml",
      normalized_hash: "hashA",
      canonical_string: "canonA",
      signature: { schemaVersion: "workflow_signature_v1", triggers: [], jobs: [] },
      embedding: [1, 0],
    });

    const drift = await store.findWorkflowDrift({
      repo: "org/repo",
      normalized_hash: "hashB",
      embedding: [0.9, 0.1],
    });

    expect(drift.drift).toBe(true);
    expect(drift.closestByEmbedding?.artifact).toBeTruthy();
    expect(store.verifyChain().valid).toBe(true);
  });
});
