import { createHash } from "node:crypto";

export type WorkflowTrigger =
  | { event: string; branches?: string[]; paths?: string[] }
  | { event: string }; // fallback minimal

export type WorkflowStepKind =
  | { kind: "uses"; uses: string; with?: Record<string, string>; name?: string }
  | { kind: "run"; runHash: string; name?: string };

export type WorkflowJobSignature =
  | {
      jobId: string;
      name?: string;
      type: "reusable";
      uses: string;
      with?: Record<string, string>;
      secrets?: "inherit" | string[];
      resolvedWorkflowHash?: string | null;
    }
  | {
      jobId: string;
      name?: string;
      type: "inline";
      runsOn?: string[];
      strategyMatrix?: Record<string, string[]>;
      steps: WorkflowStepKind[];
      artifactOps?: { upload?: string[]; download?: string[] };
    };

export type WorkflowSignature = {
  schemaVersion: "workflow_signature_v1";
  triggers: WorkflowTrigger[];
  jobs: WorkflowJobSignature[];
};

export type CanonicalWorkflow = {
  signature: WorkflowSignature;
  canonicalJson: string;
  canonicalString: string;
  normalizedHash: string; // sha256(canonicalString)
};

const clampArray = (arr?: unknown): string[] | undefined => {
  if (!arr) return undefined;
  if (typeof arr === "string") return [arr];
  if (Array.isArray(arr)) return arr.map(String);
  return undefined;
};

function normalizeUsesRef(uses: string): string {
  // Normalize action/workflow refs to reduce version noise:
  // - org/repo@v4.2.1 -> org/repo@v4
  // - org/repo@4.2.1 -> org/repo@4
  // - org/repo@<40-hex> -> org/repo@sha
  const m = uses.split("@");
  if (m.length < 2) return uses.trim();
  const base = m.slice(0, -1).join("@").trim();
  const ref = m[m.length - 1].trim();
  if (/^[0-9a-f]{40}$/i.test(ref)) return `${base}@sha`;
  const vmatch = ref.match(/^v(\d+)(?:\..*)?$/);
  if (vmatch) return `${base}@v${vmatch[1]}`;
  const sem = ref.match(/^(\d+)(?:\..*)?$/);
  if (sem) return `${base}@${sem[1]}`;
  return `${base}@${ref}`;
}

function stableStringify(value: unknown): string {
  if (value === null || typeof value !== "object") return JSON.stringify(value);
  if (Array.isArray(value)) return "[" + value.map(stableStringify).join(",") + "]";
  const obj = value as Record<string, unknown>;
  const keys = Object.keys(obj).sort();
  return (
    "{" +
    keys
      .map((k) => JSON.stringify(k) + ":" + stableStringify(obj[k]))
      .join(",") +
    "}"
  );
}

function sha256(s: string): string {
  return createHash("sha256").update(s).digest("hex");
}

function normalizeRunContent(run: unknown): string {
  const txt = typeof run === "string" ? run : JSON.stringify(run ?? "");
  // Strip trailing whitespace and normalize newlines
  return txt.replace(/\r\n/g, "\n").trim();
}

function extractArtifactOps(steps: any[]): { upload?: string[]; download?: string[] } | undefined {
  const upload: string[] = [];
  const download: string[] = [];
  for (const st of steps) {
    const uses = typeof st?.uses === "string" ? normalizeUsesRef(st.uses) : "";
    if (uses.startsWith("actions/upload-artifact@")) {
      const name = st?.with?.name ? String(st.with.name) : "artifact";
      upload.push(name);
    }
    if (uses.startsWith("actions/download-artifact@")) {
      const name = st?.with?.name ? String(st.with.name) : "artifact";
      download.push(name);
    }
  }
  if (upload.length === 0 && download.length === 0) return undefined;
  return { upload: upload.sort(), download: download.sort() };
}

export function normalizeWorkflow(
  workflow: any,
  opts?: { resolveReusable?: (uses: string) => any | null }
): WorkflowSignature {
  const on = workflow?.on ?? workflow?.["on"] ?? {};
  const triggers: WorkflowTrigger[] = [];

  if (typeof on === "string") {
    triggers.push({ event: on });
  } else if (Array.isArray(on)) {
    for (const e of on) triggers.push({ event: String(e) });
  } else if (on && typeof on === "object") {
    for (const [event, cfg] of Object.entries(on)) {
      if (!cfg || typeof cfg !== "object") {
        triggers.push({ event });
        continue;
      }
      const branches = clampArray((cfg as any).branches);
      const paths = clampArray((cfg as any).paths);
      const t: any = { event };
      if (branches) t.branches = branches.sort();
      if (paths) t.paths = paths.sort();
      triggers.push(t);
    }
  }

  triggers.sort((a, b) => a.event.localeCompare(b.event));

  const jobsObj = workflow?.jobs ?? {};
  const jobs: WorkflowJobSignature[] = [];

  for (const jobId of Object.keys(jobsObj).sort()) {
    const job = jobsObj[jobId] ?? {};
    const name = typeof job?.name === "string" ? job.name : undefined;

    if (typeof job?.uses === "string") {
      const uses = normalizeUsesRef(job.uses);
      const withObj = job?.with && typeof job.with === "object" ? job.with : undefined;
      const withNorm = withObj ? normalizeStringRecord(withObj) : undefined;

      let secrets: "inherit" | string[] | undefined;
      if (job?.secrets === "inherit") secrets = "inherit";
      else if (job?.secrets && typeof job.secrets === "object") {
        secrets = Object.keys(job.secrets).sort();
      }

      let resolvedWorkflowHash: string | null = null;
      if (opts?.resolveReusable) {
        const wf = opts.resolveReusable(uses);
        if (wf) {
          const sig = normalizeWorkflow(wf, opts);
          resolvedWorkflowHash = canonicalizeWorkflowSignature(sig).normalizedHash;
        }
      }

      jobs.push({
        jobId,
        name,
        type: "reusable",
        uses,
        with: withNorm,
        secrets,
        resolvedWorkflowHash
      });
      continue;
    }

    const runsOnRaw = job?.["runs-on"];
    const runsOn = clampArray(runsOnRaw)?.sort();

    const matrixObj = job?.strategy?.matrix && typeof job.strategy.matrix === "object" ? job.strategy.matrix : undefined;
    const strategyMatrix = matrixObj ? normalizeMatrix(matrixObj) : undefined;

    const stepsRaw = Array.isArray(job?.steps) ? job.steps : [];
    const steps: WorkflowStepKind[] = [];

    for (const st of stepsRaw) {
      const stepName = typeof st?.name === "string" ? st.name : undefined;
      if (typeof st?.uses === "string") {
        const uses = normalizeUsesRef(st.uses);
        const with = st?.with && typeof st.with === "object" ? normalizeStringRecord(st.with) : undefined;
        steps.push({ kind: "uses", uses, with, name: stepName });
      } else if (st?.run !== undefined) {
        const norm = normalizeRunContent(st.run);
        steps.push({ kind: "run", runHash: sha256(norm), name: stepName });
      }
    }

    jobs.push({
      jobId,
      name,
      type: "inline",
      runsOn,
      strategyMatrix,
      steps,
      artifactOps: extractArtifactOps(stepsRaw)
    });
  }

  return { schemaVersion: "workflow_signature_v1", triggers, jobs };
}

function normalizeStringRecord(obj: Record<string, any>): Record<string, string> {
  const out: Record<string, string> = {};
  for (const k of Object.keys(obj).sort()) {
    const v = obj[k];
    out[k] = typeof v === "string" ? v : JSON.stringify(v);
  }
  return out;
}

function normalizeMatrix(obj: Record<string, any>): Record<string, string[]> {
  const out: Record<string, string[]> = {};
  for (const k of Object.keys(obj).sort()) {
    const v = obj[k];
    if (Array.isArray(v)) out[k] = v.map(String).sort();
    else out[k] = [String(v)];
  }
  return out;
}

export function canonicalizeWorkflowSignature(sig: WorkflowSignature): CanonicalWorkflow {
  const canonicalString = stableStringify(sig);
  const canonicalJson = JSON.stringify(JSON.parse(canonicalString), null, 2);
  const normalizedHash = sha256(canonicalString);
  return { signature: sig, canonicalJson, canonicalString, normalizedHash };
}
