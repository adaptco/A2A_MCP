import { describe, expect, test } from "vitest";
import { createCITools } from "./ci-tools.js";
import { InMemoryArtifactStore } from "@agent-mesh/artifact-store";

describe("ci-tools consent", () => {
  test("denied agent produces a refusal fossil", async () => {
    const store = new InMemoryArtifactStore();
    const tools = createCITools({
      store: store as any,
      embed: async () => [0, 1],
      allowAgents: ["orchestrator"],
    });

    const sigTool = tools.find((t) => t.name === "ci.signature")!;
    const res = await sigTool.call({ workflow: { on: ["push"], jobs: {} } }, { requestingAgent: "unknown-agent" });

    expect(res.ok).toBe(false);
    const fossils = await store.fossils();
    expect(fossils.some((f) => f.event === "message_refused")).toBe(true);
    expect(store.verifyChain().valid).toBe(true);
  });
});
