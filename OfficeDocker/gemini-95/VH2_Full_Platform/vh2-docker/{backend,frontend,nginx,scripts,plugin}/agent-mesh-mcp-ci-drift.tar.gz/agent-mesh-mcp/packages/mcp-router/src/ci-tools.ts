import type { AgentId, ArtifactStore } from "@agent-mesh/core";
import { canonicalizeWorkflowSignature, normalizeWorkflow } from "@agent-mesh/core";

export type CITool = {
  name: "ci.signature" | "ci.checkDrift" | "ci.suggestPatch";
  description: string;
  inputSchema: Record<string, unknown>;
  call: (input: any, meta: { requestingAgent: AgentId }) => Promise<any>;
};

export function createCITools(deps: {
  store: ArtifactStore & {
    putWorkflowEmbedding?: (input: any) => Promise<any>;
    findWorkflowDrift?: (opts: any) => Promise<any>;
  };
  embed: (text: string) => Promise<number[]>;
  allowAgents?: AgentId[];
}): CITool[] {
  const allow = new Set<AgentId>(deps.allowAgents ?? (["orchestrator", "gateway"] as AgentId[]));

  async function refuse(requestingAgent: AgentId, toolName: string, reason: string) {
    await deps.store.fossil({
      event: "message_refused",
      agentId: "ci-tools",
      taskTreeId: undefined,
      payload: { toolName, requestingAgent, reason },
    });
    return { ok: false, denied: true, reason };
  }

  return [
    {
      name: "ci.signature",
      description: "Normalize a GitHub Actions workflow object into a canonical signature and stable hash.",
      inputSchema: {
        type: "object",
        properties: { workflow: { type: "object" } },
        required: ["workflow"],
      },
      async call(input, meta) {
        if (!allow.has(meta.requestingAgent)) return refuse(meta.requestingAgent, "ci.signature", "consent_denied");
        const sig = normalizeWorkflow(input.workflow, {
          resolveReusable: (uses) => (input.reusable_workflows ? input.reusable_workflows[uses] : null),
        });
        const canon = canonicalizeWorkflowSignature(sig);
        return { ok: true, ...canon };
      },
    },
    {
      name: "ci.checkDrift",
      description:
        "Check a workflow's normalized hash and embedding against canonical workflow embeddings stored in ArtifactStore.",
      inputSchema: {
        type: "object",
        properties: {
          repo: { type: "string" },
          ref: { type: "string" },
          workflow_path: { type: "string" },
          workflow: { type: "object" },
        },
        required: ["repo", "ref", "workflow_path", "workflow"],
      },
      async call(input, meta) {
        if (!allow.has(meta.requestingAgent)) return refuse(meta.requestingAgent, "ci.checkDrift", "consent_denied");
        const sig = normalizeWorkflow(input.workflow, {
          resolveReusable: (uses) => (input.reusable_workflows ? input.reusable_workflows[uses] : null),
        });
        const canon = canonicalizeWorkflowSignature(sig);
        const emb = await deps.embed(canon.canonicalString);

        const drift = deps.store.findWorkflowDrift
          ? await deps.store.findWorkflowDrift({ normalized_hash: canon.normalizedHash, embedding: emb, repo: input.repo })
          : { drift: true, reason: "hash_mismatch" };

        await deps.store.fossil({
          event: "ci_drift_fossil",
          agentId: "ci-tools",
          taskTreeId: undefined,
          payload: {
            repo: input.repo,
            ref: input.ref,
            workflow_path: input.workflow_path,
            normalized_hash: canon.normalizedHash,
            drift,
          },
        });

        return { ok: true, normalized: canon, drift };
      },
    },
    {
      name: "ci.suggestPatch",
      description: "Suggest a minimal wrapper patch when drift is detected (heuristic).",
      inputSchema: {
        type: "object",
        properties: {
          repo: { type: "string" },
          ref: { type: "string" },
          workflow_path: { type: "string" },
          normalized_hash: { type: "string" },
          closest: { type: "object" },
        },
        required: ["repo", "ref", "workflow_path", "normalized_hash"],
      },
      async call(input, meta) {
        if (!allow.has(meta.requestingAgent)) return refuse(meta.requestingAgent, "ci.suggestPatch", "consent_denied");
        // Heuristic: if closest artifact carries a canonical reusable uses string, suggest swapping to it.
        const closestUses =
          input?.closest?.artifact?.data?.signature?.jobs?.find?.((j: any) => j.type === "reusable")?.uses ?? null;

        const suggestion = closestUses
          ? `Update your wrapper workflow to use the canonical reusable workflow reference:\n\n  uses: ${closestUses}\n`
          : "Update your workflow to match the canonical platform-ci signature (see drift report).";

        const patch = `# Suggested change (manual apply)\n# ${suggestion}`;

        await deps.store.fossil({
          event: "artifact_written",
          agentId: "ci-tools",
          taskTreeId: undefined,
          payload: { repo: input.repo, workflow_path: input.workflow_path, normalized_hash: input.normalized_hash, patch },
        });

        return { ok: true, patch, suggestion };
      },
    },
  ];
}
