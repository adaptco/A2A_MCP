import ConsentVisualizer from './ConsentVisualizer';

export default function App() {
  return <ConsentVisualizer />;
}
